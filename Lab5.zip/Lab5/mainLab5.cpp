#define _CRT_SECURE_NO_WARNINGS 1
#include <vector>
#include <iostream>
#include <algorithm> // for std::clamp

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

int main() {
    int W, H, C;

    unsigned char* image = stbi_load("8733654151_b9422bb2ec_k.jpg", &W, &H, &C, STBI_rgb);

    std::vector<double> image_double(W * H * 3);
    for (int i = 0; i < W * H * 3; i++) {
        image_double[i] = static_cast<double>(image[i]);
    }

    std::vector<unsigned char> image_result(W * H * 3, 0);

    for (int i = 0; i < H; i++) {
        for (int j = 0; j < W; j++) {
            int idx = (i * W + j) * 3;
            double r = image_double[idx + 0];
            double g = image_double[idx + 1];
            double b = image_double[idx + 2];

            image_result[idx + 0] = static_cast<unsigned char>(std::clamp(r * 0.5, 0.0, 255.0));
            image_result[idx + 1] = static_cast<unsigned char>(std::clamp(g * 0.3, 0.0, 255.0));
            image_result[idx + 2] = static_cast<unsigned char>(std::clamp(b * 0.2, 0.0, 255.0));
        }
    }

    if (!stbi_write_png("image.png", W, H, 3, image_result.data(), 0)) {
        std::cerr << "No.\n";
        return 1;
    }

    stbi_image_free(image);

    std::cout << "image.png done.\n";
    return 0;
}
